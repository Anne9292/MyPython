create
    definer = zcz@`192.168%` procedure test_insert()
BEGIN 
DECLARE a INT DEFAULT 600000; 
WHILE (a <= 1000000) DO 
SET a = a + 1; 
insert into `tb_example_memory`(`name`,last_name) values(a, a); 
END WHILE; 
commit; 
END;

